CoordinateCleaner 1.1-0 (2018-04-08)
=========================

### NEW FEATURES

### MINOR IMPROVEMENTS

  * Adaption of code to ROpensci guidelines

### BUG FIXES

### DEPRECATED AND DEFUNCT
