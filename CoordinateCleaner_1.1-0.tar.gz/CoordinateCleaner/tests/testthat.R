library(testthat)
library(CoordinateCleaner)

test_check("CoordinateCleaner")
